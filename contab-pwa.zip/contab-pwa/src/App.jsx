import { useState, useRef, useCallback } from "react";

const CATEGORIES = {
  alimentacao: { label: "Alimentação", icon: "🍽️", color: "#f59e0b" },
  transporte: { label: "Transporte", icon: "🚗", color: "#3b82f6" },
  saude: { label: "Saúde", icon: "💊", color: "#10b981" },
  moradia: { label: "Moradia", icon: "🏠", color: "#8b5cf6" },
  servicos: { label: "Serviços", icon: "⚡", color: "#f97316" },
  compras: { label: "Compras", icon: "🛒", color: "#ec4899" },
  lazer: { label: "Lazer", icon: "🎬", color: "#06b6d4" },
  outros: { label: "Outros", icon: "📦", color: "#6b7280" },
};

const formatCurrency = (v) =>
  new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(v || 0);

const formatDate = (d) =>
  new Date(d).toLocaleDateString("pt-BR", { day: "2-digit", month: "short", year: "numeric" });

const initialTransactions = [
  { id: 1, date: "2026-04-20", merchant: "Supermercado Extra", amount: 187.5, category: "alimentacao", type: "expense", description: "Compras do mês" },
  { id: 2, date: "2026-04-22", merchant: "Posto Shell", amount: 220.0, category: "transporte", type: "expense", description: "Combustível" },
  { id: 3, date: "2026-04-25", merchant: "Farmácia São João", amount: 65.3, category: "saude", type: "expense", description: "Medicamentos" },
  { id: 4, date: "2026-04-28", merchant: "Receita Cliente ABC", amount: 3500.0, category: "servicos", type: "income", description: "Serviços de consultoria" },
];

// ── Scan Modal ────────────────────────────────────────────────────────────────
function ScanModal({ onClose, onSave }) {
  const [phase, setPhase] = useState("upload"); // upload | scanning | review | manual
  const [imagePreview, setImagePreview] = useState(null);
  const [imageBase64, setImageBase64] = useState(null);
  const [scanResult, setScanResult] = useState(null);
  const [error, setError] = useState(null);
  const [form, setForm] = useState({
    merchant: "", amount: "", date: new Date().toISOString().split("T")[0],
    category: "outros", description: "", type: "expense",
  });
  const fileRef = useRef();

  const handleFile = (file) => {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (e) => {
      setImagePreview(e.target.result);
      setImageBase64(e.target.result.split(",")[1]);
    };
    reader.readAsDataURL(file);
  };

  const scanReceipt = async () => {
    setPhase("scanning");
    setError(null);
    try {
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 1000,
          messages: [{
            role: "user",
            content: [
              {
                type: "image",
                source: { type: "base64", media_type: "image/jpeg", data: imageBase64 },
              },
              {
                type: "text",
                text: `Analise esta nota fiscal ou recibo e extraia as informações. Responda APENAS com JSON válido, sem markdown, sem texto extra:
{
  "merchant": "nome do estabelecimento",
  "amount": 0.00,
  "date": "YYYY-MM-DD",
  "category": "alimentacao|transporte|saude|moradia|servicos|compras|lazer|outros",
  "description": "descrição resumida dos itens ou serviço",
  "type": "expense|income"
}
Se não conseguir identificar algum campo, use null. Data de hoje: ${new Date().toISOString().split("T")[0]}.`,
              },
            ],
          }],
        }),
      });
      const data = await res.json();
      const text = data.content?.find((b) => b.type === "text")?.text || "{}";
      const clean = text.replace(/```json|```/g, "").trim();
      const parsed = JSON.parse(clean);
      setScanResult(parsed);
      setForm({
        merchant: parsed.merchant || "",
        amount: parsed.amount || "",
        date: parsed.date || new Date().toISOString().split("T")[0],
        category: parsed.category || "outros",
        description: parsed.description || "",
        type: parsed.type || "expense",
      });
      setPhase("review");
    } catch (e) {
      setError("Não foi possível ler a nota. Preencha manualmente.");
      setPhase("manual");
    }
  };

  const handleSave = () => {
    if (!form.merchant || !form.amount) return;
    onSave({
      id: Date.now(),
      ...form,
      amount: parseFloat(form.amount),
    });
    onClose();
  };

  const ReviewForm = () => (
    <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
      {[
        { label: "Estabelecimento", key: "merchant", type: "text" },
        { label: "Valor (R$)", key: "amount", type: "number" },
        { label: "Data", key: "date", type: "date" },
        { label: "Descrição", key: "description", type: "text" },
      ].map(({ label, key, type }) => (
        <div key={key}>
          <label style={{ fontSize: 11, fontWeight: 700, color: "#94a3b8", letterSpacing: "0.08em", textTransform: "uppercase", display: "block", marginBottom: 4 }}>{label}</label>
          <input
            type={type}
            value={form[key]}
            onChange={(e) => setForm((f) => ({ ...f, [key]: e.target.value }))}
            style={{ width: "100%", background: "#1e293b", border: "1.5px solid #334155", borderRadius: 8, padding: "8px 12px", color: "#f1f5f9", fontSize: 14, boxSizing: "border-box", outline: "none" }}
          />
        </div>
      ))}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
        <div>
          <label style={{ fontSize: 11, fontWeight: 700, color: "#94a3b8", letterSpacing: "0.08em", textTransform: "uppercase", display: "block", marginBottom: 4 }}>Tipo</label>
          <select value={form.type} onChange={(e) => setForm((f) => ({ ...f, type: e.target.value }))}
            style={{ width: "100%", background: "#1e293b", border: "1.5px solid #334155", borderRadius: 8, padding: "8px 12px", color: "#f1f5f9", fontSize: 14, outline: "none" }}>
            <option value="expense">💸 Despesa</option>
            <option value="income">💰 Receita</option>
          </select>
        </div>
        <div>
          <label style={{ fontSize: 11, fontWeight: 700, color: "#94a3b8", letterSpacing: "0.08em", textTransform: "uppercase", display: "block", marginBottom: 4 }}>Categoria</label>
          <select value={form.category} onChange={(e) => setForm((f) => ({ ...f, category: e.target.value }))}
            style={{ width: "100%", background: "#1e293b", border: "1.5px solid #334155", borderRadius: 8, padding: "8px 12px", color: "#f1f5f9", fontSize: 14, outline: "none" }}>
            {Object.entries(CATEGORIES).map(([k, v]) => (
              <option key={k} value={k}>{v.icon} {v.label}</option>
            ))}
          </select>
        </div>
      </div>
    </div>
  );

  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.75)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 100, padding: 16 }}>
      <div style={{ background: "#0f172a", border: "1.5px solid #1e293b", borderRadius: 20, width: "100%", maxWidth: 480, maxHeight: "90vh", overflowY: "auto", boxShadow: "0 25px 60px rgba(0,0,0,0.6)" }}>
        {/* Header */}
        <div style={{ padding: "20px 24px 0", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <div>
            <div style={{ fontSize: 18, fontWeight: 800, color: "#f1f5f9", fontFamily: "'Georgia', serif" }}>
              {phase === "upload" && "📷 Escanear Nota"}
              {phase === "scanning" && "🔍 Analisando..."}
              {(phase === "review" || phase === "manual") && "✏️ Confirmar Lançamento"}
            </div>
            <div style={{ fontSize: 12, color: "#64748b", marginTop: 2 }}>
              {phase === "upload" && "Tire uma foto da nota fiscal"}
              {phase === "scanning" && "A IA está lendo sua nota"}
              {phase === "review" && "Revise os dados extraídos"}
              {phase === "manual" && "Preencha os dados manualmente"}
            </div>
          </div>
          <button onClick={onClose} style={{ background: "#1e293b", border: "none", color: "#94a3b8", borderRadius: 8, width: 32, height: 32, cursor: "pointer", fontSize: 16 }}>✕</button>
        </div>

        <div style={{ padding: 24 }}>
          {/* Upload phase */}
          {phase === "upload" && (
            <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
              <div
                onClick={() => fileRef.current.click()}
                style={{ border: "2px dashed #334155", borderRadius: 16, padding: 32, textAlign: "center", cursor: "pointer", transition: "border-color 0.2s" }}
                onMouseEnter={(e) => e.currentTarget.style.borderColor = "#22d3ee"}
                onMouseLeave={(e) => e.currentTarget.style.borderColor = "#334155"}
              >
                {imagePreview ? (
                  <img src={imagePreview} alt="nota" style={{ maxHeight: 200, borderRadius: 8, maxWidth: "100%" }} />
                ) : (
                  <>
                    <div style={{ fontSize: 40, marginBottom: 12 }}>📄</div>
                    <div style={{ color: "#94a3b8", fontSize: 14 }}>Clique para selecionar uma foto</div>
                    <div style={{ color: "#475569", fontSize: 12, marginTop: 4 }}>JPG, PNG ou PDF</div>
                  </>
                )}
                <input ref={fileRef} type="file" accept="image/*" style={{ display: "none" }} onChange={(e) => handleFile(e.target.files[0])} />
              </div>
              {imagePreview && (
                <button onClick={scanReceipt} style={{ background: "linear-gradient(135deg, #06b6d4, #0284c7)", border: "none", color: "white", borderRadius: 12, padding: "14px 24px", fontSize: 15, fontWeight: 700, cursor: "pointer", letterSpacing: "0.03em" }}>
                  🤖 Analisar com IA
                </button>
              )}
              <button onClick={() => setPhase("manual")} style={{ background: "transparent", border: "1.5px solid #334155", color: "#94a3b8", borderRadius: 12, padding: "12px 24px", fontSize: 14, cursor: "pointer" }}>
                ✏️ Lançar manualmente
              </button>
            </div>
          )}

          {/* Scanning phase */}
          {phase === "scanning" && (
            <div style={{ textAlign: "center", padding: "32px 0" }}>
              <div style={{ fontSize: 48, marginBottom: 16, animation: "pulse 1s infinite" }}>🔍</div>
              <div style={{ color: "#94a3b8", marginBottom: 8 }}>Lendo a nota fiscal com IA...</div>
              <div style={{ color: "#475569", fontSize: 13 }}>Isso leva alguns segundos</div>
              <style>{`@keyframes pulse { 0%,100%{opacity:1} 50%{opacity:0.4} }`}</style>
            </div>
          )}

          {/* Review / Manual phase */}
          {(phase === "review" || phase === "manual") && (
            <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
              {phase === "review" && imagePreview && (
                <img src={imagePreview} alt="nota" style={{ height: 100, borderRadius: 8, objectFit: "cover", width: "100%" }} />
              )}
              {error && (
                <div style={{ background: "#7f1d1d22", border: "1px solid #ef4444", borderRadius: 10, padding: "10px 14px", color: "#fca5a5", fontSize: 13 }}>
                  {error}
                </div>
              )}
              {phase === "review" && (
                <div style={{ background: "#052e16", border: "1px solid #16a34a", borderRadius: 10, padding: "10px 14px", color: "#86efac", fontSize: 13, display: "flex", gap: 8 }}>
                  <span>✅</span> Nota lida com sucesso! Revise os dados abaixo.
                </div>
              )}
              <ReviewForm />
              <div style={{ display: "flex", gap: 10, marginTop: 4 }}>
                <button onClick={() => setPhase("upload")} style={{ flex: 1, background: "#1e293b", border: "none", color: "#94a3b8", borderRadius: 12, padding: "12px", fontSize: 14, cursor: "pointer" }}>
                  ← Voltar
                </button>
                <button onClick={handleSave} disabled={!form.merchant || !form.amount}
                  style={{ flex: 2, background: form.merchant && form.amount ? "linear-gradient(135deg, #10b981, #059669)" : "#1e293b", border: "none", color: form.merchant && form.amount ? "white" : "#475569", borderRadius: 12, padding: "12px", fontSize: 15, fontWeight: 700, cursor: form.merchant && form.amount ? "pointer" : "not-allowed" }}>
                  💾 Salvar Lançamento
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ── Main App ──────────────────────────────────────────────────────────────────
export default function App() {
  const [transactions, setTransactions] = useState(initialTransactions);
  const [showScan, setShowScan] = useState(false);
  const [activeTab, setActiveTab] = useState("dashboard");
  const [filterCat, setFilterCat] = useState("all");

  const expenses = transactions.filter((t) => t.type === "expense").reduce((s, t) => s + t.amount, 0);
  const income = transactions.filter((t) => t.type === "income").reduce((s, t) => s + t.amount, 0);
  const balance = income - expenses;

  const byCategory = Object.entries(CATEGORIES).map(([key, cat]) => ({
    key, ...cat,
    total: transactions.filter((t) => t.category === key && t.type === "expense").reduce((s, t) => s + t.amount, 0),
  })).filter((c) => c.total > 0).sort((a, b) => b.total - a.total);

  const filtered = filterCat === "all" ? transactions : transactions.filter((t) => t.category === filterCat);
  const sorted = [...filtered].sort((a, b) => new Date(b.date) - new Date(a.date));

  const addTransaction = (t) => setTransactions((prev) => [t, ...prev]);
  const removeTransaction = (id) => setTransactions((prev) => prev.filter((t) => t.id !== id));

  const Tab = ({ id, label, icon }) => (
    <button onClick={() => setActiveTab(id)}
      style={{ flex: 1, background: activeTab === id ? "#1e293b" : "transparent", border: "none", color: activeTab === id ? "#22d3ee" : "#64748b", padding: "10px 0", borderRadius: 10, fontSize: 12, fontWeight: activeTab === id ? 700 : 500, cursor: "pointer", display: "flex", flexDirection: "column", alignItems: "center", gap: 3 }}>
      <span style={{ fontSize: 18 }}>{icon}</span>
      {label}
    </button>
  );

  return (
    <div style={{ background: "#080f1e", minHeight: "100vh", fontFamily: "'DM Sans', 'Segoe UI', sans-serif", color: "#f1f5f9", maxWidth: 480, margin: "0 auto", position: "relative" }}>
      {/* Top bar */}
      <div style={{ padding: "24px 20px 0", display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
        <div>
          <div style={{ fontSize: 11, color: "#475569", letterSpacing: "0.12em", textTransform: "uppercase", fontWeight: 600 }}>Contab IA</div>
          <div style={{ fontSize: 22, fontWeight: 800, color: "#f1f5f9", fontFamily: "'Georgia', serif", letterSpacing: "-0.02em" }}>Painel Financeiro</div>
        </div>
        <div style={{ fontSize: 12, color: "#475569", textAlign: "right", marginTop: 4 }}>
          {new Date().toLocaleDateString("pt-BR", { month: "long", year: "numeric" })}
        </div>
      </div>

      {/* Balance card */}
      <div style={{ margin: "20px 20px 0", background: "linear-gradient(135deg, #0c4a6e 0%, #0e7490 50%, #06b6d4 100%)", borderRadius: 20, padding: 24, position: "relative", overflow: "hidden" }}>
        <div style={{ position: "absolute", top: -20, right: -20, width: 120, height: 120, background: "rgba(255,255,255,0.05)", borderRadius: "50%" }} />
        <div style={{ position: "absolute", bottom: -30, left: 60, width: 80, height: 80, background: "rgba(255,255,255,0.04)", borderRadius: "50%" }} />
        <div style={{ fontSize: 11, color: "rgba(255,255,255,0.65)", textTransform: "uppercase", letterSpacing: "0.1em", marginBottom: 6 }}>Saldo Atual</div>
        <div style={{ fontSize: 36, fontWeight: 900, color: "white", letterSpacing: "-0.03em", fontFamily: "'Georgia', serif" }}>{formatCurrency(balance)}</div>
        <div style={{ display: "flex", gap: 24, marginTop: 20 }}>
          <div>
            <div style={{ fontSize: 10, color: "rgba(255,255,255,0.55)", textTransform: "uppercase", letterSpacing: "0.08em" }}>↑ Receitas</div>
            <div style={{ fontSize: 16, fontWeight: 700, color: "#86efac" }}>{formatCurrency(income)}</div>
          </div>
          <div>
            <div style={{ fontSize: 10, color: "rgba(255,255,255,0.55)", textTransform: "uppercase", letterSpacing: "0.08em" }}>↓ Despesas</div>
            <div style={{ fontSize: 16, fontWeight: 700, color: "#fca5a5" }}>{formatCurrency(expenses)}</div>
          </div>
        </div>
      </div>

      {/* Scan button */}
      <div style={{ padding: "16px 20px 0" }}>
        <button onClick={() => setShowScan(true)}
          style={{ width: "100%", background: "linear-gradient(135deg, #22d3ee, #0ea5e9)", border: "none", color: "#030712", borderRadius: 14, padding: "15px", fontSize: 15, fontWeight: 800, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: 10, letterSpacing: "0.02em", boxShadow: "0 4px 24px rgba(34,211,238,0.3)" }}>
          <span style={{ fontSize: 20 }}>📷</span> Escanear Nota Fiscal
        </button>
      </div>

      {/* Tabs */}
      <div style={{ margin: "16px 20px 0", background: "#0f172a", borderRadius: 14, padding: 6, display: "flex", gap: 4 }}>
        <Tab id="dashboard" label="Resumo" icon="📊" />
        <Tab id="transactions" label="Lançamentos" icon="📋" />
      </div>

      {/* Dashboard tab */}
      {activeTab === "dashboard" && (
        <div style={{ padding: "16px 20px 100px" }}>
          <div style={{ fontSize: 13, fontWeight: 700, color: "#94a3b8", marginBottom: 12, textTransform: "uppercase", letterSpacing: "0.08em" }}>Por Categoria</div>
          {byCategory.length === 0 ? (
            <div style={{ textAlign: "center", color: "#475569", padding: 32, fontSize: 14 }}>Nenhuma despesa ainda</div>
          ) : byCategory.map((cat) => {
            const pct = Math.round((cat.total / expenses) * 100);
            return (
              <div key={cat.key} style={{ background: "#0f172a", borderRadius: 14, padding: "14px 16px", marginBottom: 10, border: "1px solid #1e293b" }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                    <span style={{ fontSize: 20 }}>{cat.icon}</span>
                    <div>
                      <div style={{ fontSize: 14, fontWeight: 600, color: "#e2e8f0" }}>{cat.label}</div>
                      <div style={{ fontSize: 11, color: "#64748b" }}>{pct}% do total</div>
                    </div>
                  </div>
                  <div style={{ fontSize: 15, fontWeight: 700, color: "#fca5a5" }}>{formatCurrency(cat.total)}</div>
                </div>
                <div style={{ background: "#1e293b", borderRadius: 99, height: 5 }}>
                  <div style={{ background: cat.color, height: 5, borderRadius: 99, width: `${pct}%`, transition: "width 0.5s ease" }} />
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Transactions tab */}
      {activeTab === "transactions" && (
        <div style={{ padding: "16px 20px 100px" }}>
          {/* Category filter */}
          <div style={{ display: "flex", gap: 8, overflowX: "auto", paddingBottom: 8, marginBottom: 12 }}>
            {[{ key: "all", label: "Todos", icon: "🗂️" }, ...Object.entries(CATEGORIES).map(([k, v]) => ({ key: k, label: v.label, icon: v.icon }))].map((c) => (
              <button key={c.key} onClick={() => setFilterCat(c.key)}
                style={{ background: filterCat === c.key ? "#22d3ee" : "#0f172a", border: filterCat === c.key ? "none" : "1px solid #1e293b", color: filterCat === c.key ? "#030712" : "#94a3b8", borderRadius: 99, padding: "6px 12px", fontSize: 12, fontWeight: filterCat === c.key ? 700 : 500, cursor: "pointer", whiteSpace: "nowrap", flexShrink: 0 }}>
                {c.icon} {c.label}
              </button>
            ))}
          </div>

          {sorted.length === 0 ? (
            <div style={{ textAlign: "center", color: "#475569", padding: 48 }}>
              <div style={{ fontSize: 40, marginBottom: 12 }}>📭</div>
              Nenhum lançamento encontrado
            </div>
          ) : sorted.map((t) => {
            const cat = CATEGORIES[t.category] || CATEGORIES.outros;
            return (
              <div key={t.id} style={{ background: "#0f172a", borderRadius: 14, padding: "14px 16px", marginBottom: 10, border: "1px solid #1e293b", display: "flex", alignItems: "center", gap: 14 }}>
                <div style={{ width: 44, height: 44, background: `${cat.color}22`, borderRadius: 12, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 20, flexShrink: 0 }}>
                  {cat.icon}
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 14, fontWeight: 600, color: "#e2e8f0", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{t.merchant}</div>
                  <div style={{ fontSize: 11, color: "#64748b", marginTop: 2 }}>{formatDate(t.date)} · {cat.label}</div>
                  {t.description && <div style={{ fontSize: 12, color: "#475569", marginTop: 1, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{t.description}</div>}
                </div>
                <div style={{ textAlign: "right", flexShrink: 0 }}>
                  <div style={{ fontSize: 15, fontWeight: 700, color: t.type === "income" ? "#86efac" : "#fca5a5" }}>
                    {t.type === "income" ? "+" : "-"}{formatCurrency(t.amount)}
                  </div>
                  <button onClick={() => removeTransaction(t.id)} style={{ background: "none", border: "none", color: "#334155", cursor: "pointer", fontSize: 14, marginTop: 4, padding: 0 }}>🗑</button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Scan modal */}
      {showScan && <ScanModal onClose={() => setShowScan(false)} onSave={addTransaction} />}
    </div>
  );
}
